package com.example.tubesrpg;

public abstract class Attack {
    abstract int attack(String method);
}
