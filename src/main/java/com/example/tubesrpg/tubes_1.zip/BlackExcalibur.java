package com.example.tubesrpg;

public class BlackExcalibur {
    private int point_damage = 2;

    public BlackExcalibur(){

    }

    public int getPoint_damage(){
        return point_damage;
    }
}
