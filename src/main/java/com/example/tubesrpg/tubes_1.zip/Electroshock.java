package com.example.tubesrpg;

public class Electroshock {
    private int point_damage = 8;

    public Electroshock(){

    }
    
    public int getPoint_damage() {
        return point_damage;
    }

}
