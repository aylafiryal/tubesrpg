package com.example.tubesrpg;

public class Excalibur {

    private int point_damage = 4;

    public Excalibur(){

    }

    public int getPoint_damage(){
        return point_damage;
    }
    
}
