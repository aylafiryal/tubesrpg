package com.example.tubesrpg;

public interface Heal {
    
    int addStrength();
}
