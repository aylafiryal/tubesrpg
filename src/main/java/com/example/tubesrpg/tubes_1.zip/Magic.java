package com.example.tubesrpg;

public class Magic extends Attack {
    private Teleport teleport;
    private Electroshock electroshock;
    private int damage = 10;

    public Magic(){

    }

    @Override
    public int attack(String spell){
        if(spell.equals("Teleportasi")){
            damage = damage + teleport.getPoint_damage();
        }
        if(spell.equals("Tusuk")){
            damage = damage + electroshock.getPoint_damage();
        }
        return damage;
    }

}
