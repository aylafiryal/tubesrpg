package com.example.tubesrpg;

public class Teleport {

    private int point_damage = 6;

    public Teleport(){

    }

    public int getPoint_damage(){
        return point_damage;
    }
    
}
